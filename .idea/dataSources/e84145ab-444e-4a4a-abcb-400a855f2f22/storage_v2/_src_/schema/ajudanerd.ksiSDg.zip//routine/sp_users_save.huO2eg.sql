CREATE PROCEDURE sp_users_save(IN pperson     VARCHAR(64), IN plogin VARCHAR(64), IN ppassword VARCHAR(256),
                               IN pemail      VARCHAR(128), IN pnrphone VARCHAR(14), IN pprofession VARCHAR(100),
                               IN pimgprofile VARCHAR(128), IN pidplan INT, IN pinadmin INT)
  BEGIN

    DECLARE vidperson INT;

    INSERT INTO tb_persons (person, email, nrphone, profession, imgprofile)
    VALUES (pperson, pemail, pnrphone, pprofession, pimgprofile);

    SET vidperson = LAST_INSERT_ID();

    INSERT INTO tb_users (idperson, login, password, idplan, inadmin)
    VALUES (vidperson, plogin, ppassword, pidplan, pinadmin);

    SELECT * FROM tb_users a INNER JOIN tb_persons b USING (idperson) WHERE a.iduser = LAST_INSERT_ID();

  END;

