create procedure sp_books_save(IN ptitle      varchar(150), IN pcategorybook varchar(100), IN pauthor varchar(50),
                               IN pwriter     varchar(50), IN pphoto varchar(256), IN pbook varchar(256),
                               IN pidfreepaid int, IN ppricesbook decimal(10, 2), IN pdescripion varchar(256),
                               IN piduser     int)
  BEGIN

    DECLARE vidbook INT;

    INSERT INTO tb_books (title, categorybook, author, writer, photo, book, idfreepaid, pricesbook, description, iduser)
    VALUES (ptitle, pcategorybook, pauthor, pwriter, pphoto, pbook, pidfreepaid, ppricesbook, pdescripion, piduser);

    SET vidbook = LAST_INSERT_ID();

    SELECT * FROM tb_books WHERE idbook = LAST_INSERT_ID();

  END;

