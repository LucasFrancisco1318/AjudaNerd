create procedure sp_usersupdate_save(IN piduser     int, IN pperson varchar(64), IN puser varchar(50),
                                     IN pprofession varchar(100), IN pemail varchar(128), IN pnrphone varchar(14),
                                     IN plogin      varchar(64), IN ppassword varchar(256), IN pinadmin int)
  BEGIN

    DECLARE vidperson INT;

    SELECT idperson
    INTO vidperson
    FROM tb_users
    WHERE iduser = piduser;

    UPDATE tb_persons
    SET
      person     = pperson,
      email      = pemail,
      nrphone    = pnrphone,
      profession = pprofession
    WHERE idperson = vidperson;

    UPDATE tb_users
    SET
      user     = puser,
      login    = plogin,
      password = ppassword,
      inadmin  = pinadmin
    WHERE iduser = piduser;

    SELECT *
    FROM tb_users a INNER JOIN tb_persons b USING (idperson)
    WHERE a.iduser = piduser;

  END;

