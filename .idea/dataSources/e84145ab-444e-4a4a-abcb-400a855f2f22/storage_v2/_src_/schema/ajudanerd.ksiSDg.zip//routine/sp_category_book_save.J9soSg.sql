create procedure sp_category_book_save(IN pidcategorybook int, IN pcategorybook varchar(64))
  BEGIN

    IF pidcategorybook > 0 THEN

      UPDATE tb_category_book
      SET categorybook = pcategorybook
      WHERE idcategorybook = pidcategorybook;

    ELSE

      INSERT INTO tb_category_book (categorybook) VALUES(pcategorybook);

      SET pidcategorybook = LAST_INSERT_ID();

    END IF;

    SELECT * FROM tb_category_book WHERE idcategorybook = pidcategorybook;

  END;

