CREATE PROCEDURE sp_users_save(IN pperson  VARCHAR(64), IN plogin VARCHAR(64), IN ppassword VARCHAR(256),
                               IN pemail   VARCHAR(128), IN pnrphone VARCHAR(14), IN pprofession VARCHAR(100),
                               IN pinadmin INT, IN puser VARCHAR(50))
  BEGIN

    DECLARE vidperson INT;

    INSERT INTO tb_persons (person, email, nrphone, profession)
    VALUES (pperson, pemail, pnrphone, pprofession);

    SET vidperson = LAST_INSERT_ID();

    INSERT INTO tb_users (idperson, login, password, inadmin, user)
    VALUES (vidperson, plogin, ppassword, pinadmin, puser);

    SELECT * FROM tb_users a INNER JOIN tb_persons b USING (idperson) WHERE a.iduser = LAST_INSERT_ID();

  END;

