CREATE PROCEDURE sp_usersupdate_save(IN piduser     INT, IN pperson VARCHAR(64), IN puser VARCHAR(50),
                                     IN plogin      VARCHAR(64), IN ppassword VARCHAR(256), IN pemail VARCHAR(128),
                                     IN pnrphone    VARCHAR(14), IN pprofession VARCHAR(100), IN pinadmin INT,
                                     IN pimgprofile VARCHAR(128))
  BEGIN

    DECLARE vidperson INT;

    SELECT idperson INTO vidperson
    FROM tb_users
    WHERE iduser = piduser;

    UPDATE tb_persons
      SET
        person = pperson,
        email = pemail,
        nrphone = pnrphone,
        profession = pprofession,
        imgprofile = pimgprofile
    WHERE idperson = vidperson;

    UPDATE tb_users
      SET
        user = puser,
        login = plogin,
        password = ppassword,
        inadmin = pinadmin
    WHERE iduser = piduser;

    SELECT * FROM tb_users a INNER JOIN tb_persons b USING (idperson) WHERE a.iduser = piduser;

  END;

